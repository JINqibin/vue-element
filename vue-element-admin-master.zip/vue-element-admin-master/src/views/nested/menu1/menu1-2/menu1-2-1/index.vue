<template functional>
  <div style="padding:30px;">
    <el-alert title="menu 1-2-1" type="warning" :closable="false" />
  </div>
</template>
