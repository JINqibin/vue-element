<template functional>
  <div style="padding:30px;">
    <el-alert title="menu 1-2-2" type="warning" :closable="false" />
  </div>
</template>
